/*Seleziona tutti i prodotti con un prezzo superiore a 50 euro dalla tabella Prodotti. 
Seleziona tutte le email dei clienti il cui nome inizia con la lettera 'A' dalla tabella Clienti.
 Seleziona tutti gli ordini con una quantità maggiore di 10 o con un importo totale inferiore a 100 euro dalla tabella Ordini.
 Seleziona tutti i prezzi dei prodotti il cui nome contiene la parola 'tech' indipendentemente dalla posizione nella tabella Prodotti.
 Seleziona tutti i clienti che non hanno un indirizzo email nella tabella Clienti.
 Seleziona tutti i prodotti il cui nome inizia con 'M' e termina con 'e' indipendentemente dalla lunghezza della parola nella tabella Prodotti.
 */
 
 select * from prodotti
 where Prezzo > 50;
 
 select clienti.Email
 from clienti
 where Nome like 'A%';
 
 select *
 from ordini inner join prodotti on ordini.ID_Ordine = prodotti.ID_Prodotto
 where ordini.Quantità > 10 or prodotti.Prezzo <= 100;
 
 select *
 from prodotti
 where NomeProdotto like '%tech%';
 
 select * 
 from clienti
 where Email=' ';
 
 select *
 from prodotti
 where NomeProdotto = 'M%' and '%e';