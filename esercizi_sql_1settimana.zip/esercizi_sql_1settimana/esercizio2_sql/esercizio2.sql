create schema NuovoDB

create table Prodotti(
ID_Prodotto int primary key not null auto_increment,
NomeProdotto varchar (100), 
Prezzo decimal);


insert into Prodotti(NomeProdotto,Prezzo)
values('Tablet', 300.00), 
('Mouse', 20.00),
('Tastiera', 25.00), 
('Monitor', 180.00), 
('HHD', 90.00), 
('SSD', 200.00), 
('RAM', 100.00),  
('Router', 80.00), 
('Webcam', 45.00),  
('GPU', 1250.00), 
('Trackpad', 500.00), 
('Techmagazine', 5.00), 
('Martech', 50.00);





 
CREATE TABLE Clienti (
    ID_Cliente INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    Nome VARCHAR(50),
    Email VARCHAR(50)
);


insert into Clienti(Nome,Email)
values('Antonio',' '),
('Battista','battista@mailmail.it'),
('Maria','maria@posta.it'),
('Franca','franca@lettere.it'),
('Ettore',' '),
('Arianna','arianna@posta.it'),
('Piero','piero@lavoro.it');


CREATE TABLE Ordini (
    ID_Ordine INT PRIMARY KEY,
    ID_Prodotto INT,
    ID_Cliente INT,
    Quantità INT,
    CONSTRAINT ID_Prodotto FOREIGN KEY (ID_Prodotto)
        REFERENCES Prodotti (ID_Prodotto),
    CONSTRAINT ID_Cliente FOREIGN KEY (ID_Cliente)
        REFERENCES Clienti (ID_Cliente)
);

alter table Ordini
ADD FOREIGN KEY (ID_Cliente) REFERENCES Clienti(ID_Cliente);


insert into Ordini( ID_Ordine,ID_Prodotto,Quantità)
values(1,2,10),
(2,6,2),
(3,5,3),
(4,1,1),
(5,9,1),
(6,4,2),
(7,11,6),
(8,10,2),
(9,3,3),
(10,3,1),
(11,2,1);



CREATE TABLE DettaglioOrdini (
    ID_DettaglioOrdini INT PRIMARY KEY AUTO_INCREMENT,
    ID_Ordine INT,
    ID_Prodotti INT,
    ID_Clienti INT,
    PrezzoTotale DECIMAL,
    CONSTRAINT ID_Ordine FOREIGN KEY (ID_Ordine)
        REFERENCES Ordini (ID_Ordine),
    CONSTRAINT ID_Prodotti FOREIGN KEY (ID_Prodotti)
        REFERENCES Prodotti (ID_Prodotto),
    CONSTRAINT ID_Clienti FOREIGN KEY (ID_Clienti)
        REFERENCES Clienti (ID_Cliente)
);


