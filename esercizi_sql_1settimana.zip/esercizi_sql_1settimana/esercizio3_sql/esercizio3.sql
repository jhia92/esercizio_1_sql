/*Seleziona tutti gli impiegati con una laurea in Economia. 
Seleziona gli impiegati che lavorano come Cassiere o che hanno un Diploma di Informatica.
 Seleziona i nomi e i titoli degli impiegati che hanno iniziato a lavorare dopo il 1 gennaio 2023.
 Seleziona i titoli di studio distinti tra gli impiegati. Seleziona gli impiegati con un titolo di studio diverso da "Laurea in Economia". 
 Seleziona gli impiegati che hanno iniziato a lavorare prima del 1 luglio 2023 e sono Commessi.
 Seleziona i titoli e gli sviluppatori dei videogiochi distribuiti nel 2020. 
 Seleziona i titoli dei videogiochi disponibili nei settori 1 o 3 del negozio 5.
 Seleziona i negozi con più di 
20 copie disponibili di almeno un videogioco.
*/

select * from impiegato where TitoloStudio = 'Laurea_in_Economia';

select * from impiegato 
inner join servizio_impiegato on impiegato.CodiceFiscale = servizio_impiegato.CodiceFiscale
where Carica = 'Cassiere' or TitoloStudio = 'Diploma di Informatica';

-- select * from impiegato 
-- inner join servizio_impiegato on impiegato.CodiceFiscale = servizio_impiegato.CodiceFiscale;


select impiegato.Nome, impiegato.TitoloStudio
from impiegato
inner join servizio_impiegato on impiegato.CodiceFiscale = servizio_impiegato.CodiceFiscale
where DataInizio > '2023-01-01';


select distinct impiegato.TitoloStudio
from impiegato;

select *
from impiegato
where not TitoloStudio = 'Laurea_in_Economia';

select *
from impiegato
inner join servizio_impiegato on impiegato.CodiceFiscale = servizio_impiegato.CodiceFiscale
where DataInizio < '2023-07-01' and Carica = 'Commesso';


select videogioco.Titolo , videogioco.Sviluppatore
from videogioco
where AnnoDistribuzione = '2020';

-- Seleziona i titoli dei videogiochi disponibili nei settori 1 o 3 del negozio 5.

select CollocazioneVideogioco.titolo
from CollocazioneVideogioco
inner join Store on collocazionevideogioco.CodiceStore = store.CodiceStore
where collocazionevideogioco.id_C = 5 or 3 and store.codicestore = 5;

select * from store inner join collocazionevideogioco on store.CodiceStore = collocazionevideogioco.CodiceStore
where collocazionevideogioco.num_copie > 20;

