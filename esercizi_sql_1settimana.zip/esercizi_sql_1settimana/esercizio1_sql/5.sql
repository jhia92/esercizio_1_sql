create table impiegato (
CodiceFiscale varchar(250) not null primary key ,
Nome varchar(250),
TitoloStudio varchar(250),
Recapito varchar(250)
);


insert into impiegato (CodiceFiscale,Nome,TitoloStudio,Recapito)
values('ABC12345XYZ67890','Mario_Rossi','Laurea_in_Economia','mario.rossi@email.com'),
('DEF67890XYZ12345','Anna_Verdi','Diploma di Ragioneria','anna.verdi@email.com'),           
('GHI12345XYZ67890','Luigi_Bianchi','Laurea in Informatica','luigi.bianchi@email.com'),
('JKL67890XYZ12345','Laura_Neri','Laurea in Lingue','laura.neri@email.com'), 
('MNO12345XYZ67890','Andrea_Moretti','Laurea in Psicologia','andrea.moretti@email.com'),  
('PQR67890XYZ12345','Giulia_Ferrara', 'Laurea in Psicologia','giulia.ferrara@email.com'), 
('STU12345XYZ67890','Marco_Esposito','Diploma di Elettronica','marco.esposito@email.com'), 
('VWX67890XYZ12345','Sara_Romano','Laurea in Giurisprudenza','sara.romano@email.com'),   
('YZA12345XYZ67890','Roberto_De_Luca','Diploma di Informatica','roberto.deluca@email.com'),  
('BCD67890XYZ12345','Elena_Santoro','Laurea in Lettere','elena.santoro@email.com');
                    
         