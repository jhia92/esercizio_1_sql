create table Servizio_Impiegato (
CodiceFiscale varchar(255) not null unique,
CodiciStore int not null unique auto_increment,
DataInizio date,
DataFine date,
Carica varchar(255),
constraint CodiceFiscale FOREIGN KEY (CodiceFiscale)
REFERENCES Impiegato(CodiceFiscale),
constraint CodiciStore foreign key (CodiciStore)
references store (CodiceStore)
);



insert into Servizio_Impiegato(CodiceFiscale,DataInizio,DataFine,Carica)
values( 'ABC12345XYZ67890','2023-01-01','2023-12-31','Cassiere'),
('DEF67890XYZ12345','2023-02-01','2023-11-30','Commesso'),  
('GHI12345XYZ67890','2023-03-01','2023-10-31','Magazziniere'), 
('JKL67890XYZ12345','2023-04-01','2023-09-30','Addetto alle vendite'),  
('MNO12345XYZ67890','2023-05-01','2023-08-31','Addetto alle pulizie'),  
('PQR67890XYZ12345', '2023-06-01','2023-07-31','Commesso'),  
('STU12345XYZ67890', '2023-07-01','2023-06-30','Commesso'),  
('VWX67890XYZ12345','2023-08-01','2023-05-31','Cassiere'),
('YZA12345XYZ67890', '2023-09-01','2023-04-30','Cassiere'), 
('BCD67890XYZ12345','2023-10-01','2023-03-31','Cassiere');
 
 
 
   