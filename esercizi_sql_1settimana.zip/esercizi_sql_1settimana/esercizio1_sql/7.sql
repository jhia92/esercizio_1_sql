create table Videogioco(
Titolo varchar(255) primary key,
Sviluppatore varchar(255),
AnnoDistribuzione year,
CostoAquisto decimal,
genere varchar(255),
RemakeDI varchar(255) default(null)
);

/*
alter table Videogioco add CodiceStore int not null 
constraint CodiceStore foreign key (Codicestore) references  store(CodiceStore);

alter table Videogioco drop column CodiceStore;
*/

insert into Videogioco(Titolo,Sviluppatore,AnnoDistribuzione,CostoAquisto,genere)
values( 'Fifa 2023','EA Sports','2023',49.99,'Calcio'),
 ("Assassin's Creed: Valhalla",'Ubisoft','2020',59.99,'Action'),
 ('Super Mario Odyssey','Nintendo','2017', 39.99,'Platform'),
 ('The Last of Us Part II','Naughty Dog ','2020',69.99,'Action'),  
 ('Cyberpunk 2077','CD Projekt Red','2020', 49.99,'RPG'), 
 ('Animal Crossing: New Horizons','Nintendo','2020',54.99,'Simulation'),
 ('Call of Duty: Warzone','Infinity Ward ','2020', 0.00,'FPS'), 
 ('The Legend of Zelda: Breath of the Wild',' Nintendo','2017',59.99,'Action_Adventure'),   
 ('Fortnite',' Epic Games ','2017',0.00,'Battle_Royal'),
 ('Red Dead Redemption 2','Rockstar Games','2018',39.99,'Action_Adventure');
                  
  select * from videogioco                