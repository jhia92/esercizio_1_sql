CREATE TABLE CollocazioneVideogioco (
    Id_C INT PRIMARY KEY NOT NULL AUTO_INCREMENT primary key,
    CodiceStore INT ,
    Titolo VARCHAR(255),
    settore int,
    num_copie int,
    CONSTRAINT CodiceStore FOREIGN KEY (CodiceStore)
        REFERENCES store (CodiceStore),
    CONSTRAINT Titolo FOREIGN KEY (Titolo)
        REFERENCES Videogioco (Titolo)
);
drop table collocazionevideogioco;
	/*ID_DISP INT NOT NULL AUTO_INCREMENT  PRIMARY KEY,
    TITOLO VARCHAR(50) NOT NULL,
	CODICE_STORE INT NOT NULL,
    SETTORE INT,
    NUM_COPIE INT,
	FOREIGN KEY (TITOLO) REFERENCES VIDEOGIOCO(TITOLO),
	FOREIGN KEY (CODICE_STORE) REFERENCES STORE(CODICE_STORE)
);
*/

insert into CollocazioneVideogioco (CodiceStore,Titolo)
values (1,'Fifa 2023'),
(2,'Fifa 2023'),
(3,'Fifa 2023'),
(4,'Fifa 2023'),
(5,'Fifa 2023'),
(6,'Fifa 2023'),
(7,'Fifa 2023'),
(8,'Fifa 2023'),
(9,'Fifa 2023'),
(10,'Fifa 2023');

insert into CollocazioneVideogioco (CodiceStore,Titolo)
values (1,"Assassin's Creed: Valhalla"),
(2,"Assassin's Creed: Valhalla"),
(3,"Assassin's Creed: Valhalla"),
(4,"Assassin's Creed: Valhalla"),
(5,"Assassin's Creed: Valhalla"),
(6,"Assassin's Creed: Valhalla"),
(7,"Assassin's Creed: Valhalla"),
(8,"Assassin's Creed: Valhalla"),
(9,"Assassin's Creed: Valhalla"),
(10,"Assassin's Creed: Valhalla");
 
 
 insert into CollocazioneVideogioco (CodiceStore,Titolo)
values (1,'Call of Duty: Warzone'),
-- (2,'Fifa 2023'),
(3,'Call of Duty: Warzone'),
-- 
(5,'Call of Duty: Warzone'),
-- 
(7,'Call of Duty: Warzone'),
-- (8,'Fifa 2023'),
(9,'Call of Duty: Warzone');
-- (10,'Fifa 2023');
 
  insert into CollocazioneVideogioco (CodiceStore,Titolo)
values (1,'Fortnite'),
-- (2,'Fifa 2023'),
(3,'Fortnite'),
-- 
(5,'Fortnite'),
-- 
(7,'Fortnite'),
-- (8,'Fifa 2023'),
(9,'Fortnite');
-- (10,'Fifa 2023');
 
 insert into CollocazioneVideogioco (CodiceStore,Titolo)
values -- (1,'Fifa 2023'),
(2,'Red Dead Redemption 2'),
-- (3,'Fifa 2023'),
(4,'Red Dead Redemption 2'),
-- (5,'Fifa 2023'),
(6,'Red Dead Redemption 2'),
-- (7,'Fifa 2023'),
(8,'Red Dead Redemption 2'),
-- (9,'Fifa 2023'),
(10,'Red Dead Redemption 2');
 
 insert INTO CollocazioneVideogioco(Titolo,CodiceStore,settore,num_copie)
VALUES
("Fifa 2023",1,1,37),
("Fifa 2023",2,1,10),
("Fifa 2023",3,1,4),
("Fifa 2023",4,1,39),
("Fifa 2023",5,1,24),
("Fifa 2023",6,1,14),
("Fifa 2023",7,1,10),
("Fifa 2023",8,1,38),
("Fifa 2023",9,1,27),
("Fifa 2023",10,1,38),
("Assassin's Creed: Valhalla",2,3,14),
("Assassin's Creed: Valhalla",10,3,19),
("Assassin's Creed: Valhalla",1,3,31),
("Assassin's Creed: Valhalla",3,3,33),
("Assassin's Creed: Valhalla",7,3,39),
("Assassin's Creed: Valhalla",9,3,14),
("Super Mario Odyssey",4,2,13),
("Super Mario Odyssey",7,2,19),
("Super Mario Odyssey",9,2,2),
("Super Mario Odyssey",1,2,1),
("Super Mario Odyssey",8,2,5),
("The Last of Us Part II",3,3,12),
("The Last of Us Part II",7,3,33),
("The Last of Us Part II",9,3,19),
("The Last of Us Part II",5,3,2),
("The Last of Us Part II",2,3,1),
("Cyberpunk 2077",6,4,28),
("Cyberpunk 2077",8,4,15),
("Cyberpunk 2077",5,4,26),
("Animal Crossing: New Horizons",9,2,29),
("Animal Crossing: New Horizons",6,2,40),
("Call of Duty: Warzone",6,4,38),
("Call of Duty: Warzone",4,4,32),
("Call of Duty: Warzone",5,4,38),
("The Legend of Zelda: Breath of the Wild",5,2,21),
("The Legend of Zelda: Breath of the Wild",8,2,32),
("The Legend of Zelda: Breath of the Wild",4,2,34),
("Fortnite",4,5,38),
("Fortnite",10,5,33),
("Fortnite",3,5,30),
("Fortnite",2,5,37),
("Fortnite",1,5,5),
("Red Dead Redemption 2",8,5,27),
("Red Dead Redemption 2",3,5,11),
("Red Dead Redemption 2",7,5,36);
 
 -- delete from CollocazioneVideogioco where id_c >20
 
 select * from CollocazioneVideogioco