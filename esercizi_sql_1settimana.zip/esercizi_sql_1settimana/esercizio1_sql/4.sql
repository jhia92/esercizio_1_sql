create schema videogiochi;

create table store 
(CodiceStore int not null primary key,
IndirizzoFisico varchar(250),
NumeroTelefono varchar(250));


insert into store (CodiceStore,IndirizzoFisico,NumeroTelefono)
values (1,'Via_Roma_123_Milano','+39021234567'),
(2,'Corso_Italia_456_Roma','+39067654321'),
(3,'Piazza_San_Marco_789_Venezia','+390419876543'),
(4,'Viale_Degli_ulivi_243_Napoli','+390813456786'),
(5,'Via_Torino_567_Torino','+390118765432'),
(6,'Corso_Vittorio_Emanuele_890_Firenze','+390552345678'),
(7,'Piazza_del_Duomo_123_Bologna','+390518765423'),
(8,'Via_Garibaldi_456_Genova','+390102345678'),
(9,'Lugarno_Mediceo_789_Pisa','+390508765432'),
(10,'Corso_Cavour_101_Palermo','+390912345678');

select * from store

